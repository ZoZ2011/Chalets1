import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { chalets } from "@/lib/chalets";
import {
  getBookedDates,
  isoToDate,
  setBookedDates,
  subscribeBookings,
  toIso,
  toggleBookedDate,
} from "@/lib/bookings";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "لوحة التحكم | لاسيرينا" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const [activeId, setActiveId] = useState<string>(chalets[0].id);
  const [bookedIso, setBookedIso] = useState<string[]>(() => getBookedDates(activeId));

  useEffect(() => {
    setBookedIso(getBookedDates(activeId));
    return subscribeBookings(() => setBookedIso(getBookedDates(activeId)));
  }, [activeId]);

  const bookedDates = useMemo(() => bookedIso.map(isoToDate), [bookedIso]);
  const activeChalet = chalets.find((c) => c.id === activeId)!;

  const handleDayClick = (day: Date) => {
    toggleBookedDate(activeId, toIso(day));
  };

  const handleClearAll = () => {
    if (confirm("هل تريد مسح كل أيام الحجز لهذا الشاليه؟")) {
      setBookedDates(activeId, []);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← الصفحة الرئيسية</Link>
          <h1 className="text-lg font-semibold">لوحة تحكم الحجوزات</h1>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-6 py-8">
        <div className="mb-6 flex flex-wrap gap-2">
          {chalets.map((c) => (
            <Button
              key={c.id}
              variant={c.id === activeId ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveId(c.id)}
            >
              {c.title} — {c.subtitle}
            </Button>
          ))}
        </div>

        <div className="rounded-2xl border bg-card p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">{activeChalet.subtitle}</p>
              <h2 className="text-xl font-semibold">{activeChalet.title}</h2>
            </div>
            <Button variant="ghost" size="sm" onClick={handleClearAll}>مسح الكل</Button>
          </div>

          <p className="mb-4 text-sm text-muted-foreground">
            اضغط على أي يوم لتحديده كمحجوز (أسود)، اضغط مرة أخرى لإلغاء الحجز.
          </p>

          <div className="flex flex-col items-center gap-6">
            <Calendar
              mode="single"
              onDayClick={handleDayClick}
              modifiers={{ booked: bookedDates }}
              modifiersClassNames={{
                booked: "bg-foreground text-background hover:bg-foreground/90",
              }}
              className="rounded-md border p-3 pointer-events-auto"
            />
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <span className="inline-block h-4 w-4 rounded bg-foreground" />
                <span>محجوز</span>
              </div>
              <span className="text-muted-foreground">
                إجمالي الأيام المحجوزة: {bookedIso.length}
              </span>
            </div>
          </div>

          <div className="mt-6 border-t pt-4">
            <h3 className="mb-2 text-sm font-semibold">الأيام المحجوزة</h3>
            {bookedIso.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا يوجد أيام محجوزة.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {[...bookedIso].sort().map((iso) => (
                  <button
                    key={iso}
                    onClick={() => toggleBookedDate(activeId, iso)}
                    className="rounded-full border bg-muted px-3 py-1 text-xs hover:bg-destructive hover:text-destructive-foreground"
                    title="اضغط لإلغاء الحجز"
                  >
                    {iso} ×
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}