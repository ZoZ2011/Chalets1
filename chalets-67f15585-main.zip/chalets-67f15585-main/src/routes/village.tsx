import { createFileRoute, Link } from "@tanstack/react-router";
import v1 from "@/assets/village/1.jpeg";
import v2 from "@/assets/village/2.jpeg";
import v3 from "@/assets/village/3.jpeg";
import v4 from "@/assets/village/4.jpeg";
import v5 from "@/assets/village/5.jpeg";
import v6 from "@/assets/village/6.jpeg";
import v7 from "@/assets/village/7.jpeg";
import v8 from "@/assets/village/8.jpeg";
import v9 from "@/assets/village/9.jpeg";
import v10 from "@/assets/village/10.jpeg";
import v11 from "@/assets/village/11.jpeg";
import v12 from "@/assets/village/12.jpeg";
import v13 from "@/assets/village/13.jpeg";
import v14 from "@/assets/village/14.jpeg";

export const Route = createFileRoute("/village")({
  head: () => ({
    meta: [
      { title: "صور قرية لاسيرينا العين السخنة" },
      { name: "description", content: "استعرض صور قرية لاسيرينا في العين السخنة: الشواطئ، المسابح، والمرافق." },
      { property: "og:title", content: "صور قرية لاسيرينا" },
      { property: "og:description", content: "صور من داخل قرية لاسيرينا العين السخنة." },
    ],
  }),
  component: VillagePage,
});

function VillagePage() {
  const sources = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14];
  const photos = sources.map((src, i) => ({ src, alt: `قرية لاسيرينا - صورة ${i + 1}` }));

  return (
    <div
      dir="rtl"
      lang="ar"
      className="min-h-screen w-full"
      style={{
        fontFamily: '"Noto Sans Arabic", "Be Vietnam Pro", sans-serif',
        backgroundColor: "#111415",
        color: "#e1e3e4",
      }}
    >
      <header className="sticky top-0 z-20 border-b border-white/10 backdrop-blur" style={{ backgroundColor: "rgba(6,18,36,0.7)" }}>
        <div className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-4 sm:px-10 md:px-20">
          <Link to="/" className="text-sm text-white/70 transition hover:text-white">← العودة</Link>
          <h1 className="text-lg font-semibold text-white">صور القرية</h1>
        </div>
      </header>

      <section className="mx-auto max-w-[1440px] px-5 py-14 sm:px-10 md:px-20">
        <div className="mb-10 text-center">
          <p className="text-[11px] font-bold uppercase tracking-[0.3em]" style={{ color: "#E5DACE" }}>VILLAGE GALLERY</p>
          <h2 className="mt-3 text-3xl font-bold text-white sm:text-4xl">صور من داخل لاسيرينا</h2>
          <p className="mx-auto mt-3 max-w-2xl text-white/70">جولة بصرية في القرية: الشواطئ، المسابح، والمرافق.</p>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {photos.map((p, i) => (
            <div key={i} className="overflow-hidden rounded-2xl border border-white/10 bg-white/5">
              <img src={p.src} alt={p.alt} className="h-56 w-full object-cover sm:h-64" />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}