import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getChalet } from "@/lib/chalets";
import { getBookedDates, isoToDate, subscribeBookings } from "@/lib/bookings";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/chalet/$id/book")({
  head: ({ params }) => {
    const c = getChalet(params.id);
    return {
      meta: [
        { title: c ? `حجز ${c.title} - ${c.subtitle} | لاسيرينا` : "حجز شاليه | لاسيرينا" },
        { name: "description", content: "اختر تاريخ الحجز وشاهد الأيام المتاحة والسعر." },
      ],
    };
  },
  loader: ({ params }) => {
    const chalet = getChalet(params.id);
    if (!chalet) throw notFound();
    return { chalet };
  },
  notFoundComponent: () => (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background p-6 text-center">
      <div>
        <h1 className="text-2xl font-bold">الشاليه غير موجود</h1>
        <Link to="/" className="mt-4 inline-block text-primary underline">العودة للصفحة الرئيسية</Link>
      </div>
    </div>
  ),
  errorComponent: ({ reset }) => (
    <div dir="rtl" className="flex min-h-screen items-center justify-center p-6">
      <Button onClick={() => reset()}>حاول مرة أخرى</Button>
    </div>
  ),
  component: BookingPage,
});

function BookingPage() {
  const { chalet } = Route.useLoaderData();
  const [bookedIso, setBookedIso] = useState<string[]>(() => getBookedDates(chalet.id));

  useEffect(() => {
    setBookedIso(getBookedDates(chalet.id));
    return subscribeBookings(() => setBookedIso(getBookedDates(chalet.id)));
  }, [chalet.id]);

  const bookedDates = bookedIso.map(isoToDate);

  return (
    <div
      dir="rtl"
      lang="ar"
      className="min-h-screen w-full"
      style={{
        fontFamily: '"Noto Sans Arabic", "Be Vietnam Pro", sans-serif',
        backgroundColor: "#111415",
        color: "#e1e3e4",
      }}
    >
      <header className="sticky top-0 z-20 border-b border-white/10 backdrop-blur" style={{ backgroundColor: "rgba(6,18,36,0.7)" }}>
        <div className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-4 sm:px-10 md:px-20">
          <Link to="/chalet/$id" params={{ id: chalet.id }} className="text-sm text-white/70 transition hover:text-white">
            ← رجوع للشاليه
          </Link>
          <div className="text-right">
            <p className="text-[11px] font-bold uppercase tracking-[0.25em]" style={{ color: "#E5DACE" }}>{chalet.subtitle}</p>
            <h1 className="text-lg font-semibold text-white">حجز {chalet.title}</h1>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-4xl px-5 py-12 sm:px-10">
        <div
          className="rounded-2xl p-6 sm:p-10"
          style={{
            background: "linear-gradient(135deg, rgba(10,25,47,0.9), rgba(6,18,36,0.95))",
            border: "1px solid rgba(229,218,206,0.2)",
          }}
        >
          <div className="mb-8 text-center">
            <p className="text-[11px] font-bold uppercase tracking-[0.3em]" style={{ color: "#E5DACE" }}>AVAILABILITY</p>
            <h2 className="mt-3 text-2xl font-semibold text-white sm:text-3xl">جدول الحجوزات</h2>
            <p className="mt-2 text-sm text-white/70">الأيام الخضراء محجوزة</p>
            <p className="mt-3 text-sm text-white/80">
              للسعر تواصل معنا على واتساب أو اتصل بنا.
            </p>
          </div>

          <div className="flex flex-col items-center gap-6">
            <Calendar
              modifiers={{ booked: bookedDates }}
              modifiersClassNames={{
                booked:
                  "bg-reserved text-reserved-foreground line-through opacity-90 hover:bg-reserved",
              }}
              className="pointer-events-auto w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white sm:p-6 [&_table]:w-full [&_button]:h-14 [&_button]:w-14 [&_button]:text-lg sm:[&_button]:h-16 sm:[&_button]:w-16 sm:[&_button]:text-xl [&_th]:text-base [&_th]:text-white/70 [&_caption]:text-lg [&_caption]:font-semibold [&_caption]:text-white"
            />
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-white/80">
              <div className="flex items-center gap-2">
                <span className="inline-block h-5 w-5 rounded bg-reserved" />
                <span>محجوز</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="inline-block h-5 w-5 rounded border border-white/30 bg-white/10" />
                <span>متاح</span>
              </div>
            </div>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <a
              href="https://wa.me/201066380092"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full px-6 py-3 text-sm font-semibold transition hover:opacity-90"
              style={{ backgroundColor: "#E5DACE", color: "#0a192f" }}
            >
              تواصل لمعرفة السعر
            </a>
            <a
              href="tel:01066380092"
              className="rounded-full border px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
              style={{ borderColor: "rgba(229,218,206,0.5)" }}
            >
              اتصل بنا
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}