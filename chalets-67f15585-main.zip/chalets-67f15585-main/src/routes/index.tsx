import { createFileRoute } from "@tanstack/react-router";
import { Link, useNavigate } from "@tanstack/react-router";
import { useRef } from "react";
import { Phone, MessageCircle } from "lucide-react";
import bg from "@/assets/lasirena-bg.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "تأجير شاليهات لاسيرينا العين السخنة" },
      { name: "description", content: "تأجير شاليهات لاسيرينا في العين السخنة — غرفتين، ثلاث غرف، بحديقة وأكثر." },
      { property: "og:title", content: "تأجير شاليهات لاسيرينا العين السخنة" },
      { property: "og:description", content: "تأجير شاليهات لاسيرينا في العين السخنة." },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;600;700&family=Noto+Sans+Arabic:wght@400;600;700&display=swap",
      },
    ],
  }),
  component: Index,
});

const chalets = [
  { id: 'red-carpet', title: 'شاليه غرفتين', subtitle: 'RED CARPET', desc: 'دور تاني علوي' },
  { id: 'b14', title: 'شاليه غرفتين', subtitle: 'RED CARPET', desc: 'دور أول علوي' },
  { id: 'lagoon-view', title: 'غرفة ورسبشن', subtitle: 'POOL VIEW', desc: 'دور ارضي بجاردن' },
];

function Index() {
  const navigate = useNavigate();
  const sequenceRef = useRef<number>(0);
  const logoClicksRef = useRef<{ count: number; last: number }>({ count: 0, last: 0 });

  const handleSecretClick = (expected: number) => {
    if (sequenceRef.current === expected) {
      sequenceRef.current = expected + 1;
      if (sequenceRef.current === 3) {
        sequenceRef.current = 0;
        navigate({ to: "/admin" });
      }
    } else {
      sequenceRef.current = expected === 0 ? 1 : 0;
    }
  };

  const handleLogoClick = () => {
    const now = Date.now();
    if (now - logoClicksRef.current.last > 1200) {
      logoClicksRef.current.count = 0;
    }
    logoClicksRef.current.count += 1;
    logoClicksRef.current.last = now;
    if (logoClicksRef.current.count >= 3) {
      logoClicksRef.current.count = 0;
      navigate({ to: "/admin" });
    }
  };

  return (
    <div
      dir="rtl"
      lang="ar"
      className="min-h-screen w-full"
      style={{
        fontFamily: '"Noto Sans Arabic", "Be Vietnam Pro", sans-serif',
        backgroundColor: "#111415",
        color: "#e1e3e4",
      }}
    >
      {/* HERO */}
      <section className="relative h-screen min-h-[640px] w-full overflow-hidden">
        <img
          src={bg}
          alt="لاسيرينا العين السخنة"
          className="ken-burns absolute inset-0 h-full w-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to bottom, rgba(6,18,36,0.55) 0%, rgba(6,18,36,0.35) 40%, rgba(6,18,36,0.9) 100%)",
          }}
        />

        {/* Top bar */}
        <div className="relative z-20 mx-auto flex max-w-[1440px] items-center justify-between px-5 py-6 sm:px-10 md:px-20">
          <div
            onClick={handleLogoClick}
            className="cursor-pointer select-none text-xl font-bold tracking-wider text-white"
          >
            La Sirena
          </div>
          <nav className="hidden items-center gap-8 text-sm text-white/80 lg:flex">
            <a href="#chalets" className="transition hover:text-white">الشاليهات</a>
            <a href="#features" className="transition hover:text-white">المميزات</a>
            <Link to="/village" className="transition hover:text-white">صور القرية</Link>
          </nav>
          <a
            href="#chalets"
            className="rounded-full px-5 py-2.5 text-sm font-semibold transition hover:opacity-90"
            style={{ backgroundColor: "#E5DACE", color: "#0a192f" }}
          >
            احجز الآن
          </a>
        </div>

        {/* Hero content */}
        <div className="relative z-10 mx-auto flex h-[calc(100%-92px)] max-w-[1440px] flex-col items-center justify-center px-5 text-center sm:px-10">
          <p className="text-[11px] font-bold uppercase tracking-[0.3em] text-[#E5DACE] sm:text-xs">
            ALPINE LUXURY MEETS COASTAL SERENITY
          </p>
          <h1
            className="text-glow mt-6 max-w-4xl text-5xl font-bold leading-[1.1] tracking-tight text-white sm:text-6xl md:text-7xl"
          >
            <span onClick={() => handleSecretClick(0)} className="cursor-pointer select-none">تأجير</span>{" "}
            <span onClick={() => handleSecretClick(1)} className="cursor-pointer select-none">شاليهات</span>{" "}
            <span onClick={() => handleSecretClick(2)} className="cursor-pointer select-none">لاسيرينا</span>
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-white/85 sm:text-lg">
            اعرف سعر تأجير شاليهك في لاسيرينا العين السخنة حسب النوع والموقع.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <a
              href="https://wa.me/201066380092"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border px-5 py-2.5 text-sm font-semibold backdrop-blur-md transition hover:bg-white/10"
              style={{ borderColor: "rgba(229,218,206,0.5)", color: "#E5DACE" }}
            >
              <MessageCircle className="h-4 w-4" />
              واتساب
            </a>
            <a
              href="tel:01066380092"
              className="inline-flex items-center gap-2 rounded-full border px-5 py-2.5 text-sm font-semibold backdrop-blur-md transition hover:bg-white/10"
              style={{ borderColor: "rgba(229,218,206,0.5)", color: "#E5DACE" }}
            >
              <Phone className="h-4 w-4" />
              اتصل بنا
            </a>
            <Link
              to="/village"
              className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition hover:opacity-90"
              style={{ backgroundColor: "#E5DACE", color: "#0a192f" }}
            >
              صور القرية
              <span aria-hidden>←</span>
            </Link>
          </div>
        </div>

        {/* scroll cue */}
        <div className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 animate-bounce text-white/70">
          <span className="text-3xl">⌄</span>
        </div>
      </section>

      {/* CHALETS */}
      <section id="chalets" className="mx-auto max-w-[1440px] px-5 py-20 sm:px-10 md:px-20 md:py-28">
        <div className="mb-14 text-center">
          <p className="text-[11px] font-bold uppercase tracking-[0.3em]" style={{ color: "#E5DACE" }}>
            ACCOMMODATIONS
          </p>
          <h2 className="mt-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
            الشاليهات الفاخرة
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base text-white/70 sm:text-lg">
            اختر من مجموعتنا المنتقاة من الشاليهات الفاخرة، كلٌ منها مصمم ليمنحك تجربة إقامة ساحلية لا تُنسى.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {chalets.map((c) => (
            <Link
              key={c.id}
              to="/chalet/$id"
              params={{ id: c.id }}
              className="glass-card group block rounded-xl p-8"
            >
              <p className="text-[11px] font-bold uppercase tracking-[0.25em]" style={{ color: "#E5DACE" }}>
                {c.subtitle}
              </p>
              <h3 className="mt-3 text-2xl font-semibold text-white sm:text-3xl">{c.title}</h3>
              <p className="mt-4 text-sm leading-relaxed text-white/70 sm:text-base">{c.desc}</p>
              <span
                className="mt-6 inline-flex items-center gap-2 text-sm font-semibold transition group-hover:gap-3"
                style={{ color: "#E5DACE" }}
              >
                اطلب تأجير
                <span aria-hidden>←</span>
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="mx-auto max-w-[1440px] px-5 py-20 sm:px-10 md:px-20 md:py-28">
        <div className="mb-14 text-center">
          <p className="text-[11px] font-bold uppercase tracking-[0.3em]" style={{ color: "#E5DACE" }}>
            RESORT FEATURES
          </p>
          <h2 className="mt-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
            فن العيش الساحلي
          </h2>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { t: "حمامات سباحة", d: "استمتع بحمامات السباحة المميزة المصممة للهدوء التام." },
            { t: "مطاعم راقية", d: "تجارب طعام بأيدي طهاة عالميين داخل القرية." },
            { t: "شاطئ خاص", d: "رمال ناعمة ومياه صافية على بُعد خطوات منك." },
            { t: "سبا وعافية", d: "علاجات شاملة في مركز عافية على مستوى عالمي." },
          ].map((f) => (
            <div key={f.t} className="glass-card rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white">{f.t}</h3>
              <p className="mt-3 text-sm leading-relaxed text-white/70">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-[1440px] px-5 pb-20 sm:px-10 md:px-20 md:pb-28">
        <div
          className="rounded-2xl px-6 py-14 text-center sm:px-12"
          style={{
            background:
              "linear-gradient(135deg, rgba(10,25,47,0.9), rgba(6,18,36,0.95))",
            border: "1px solid rgba(229,218,206,0.2)",
          }}
        >
          <h2 className="text-3xl font-bold text-white sm:text-4xl">
            مستعد للهروب إلى العين السخنة؟
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base text-white/75 sm:text-lg">
            اختبر المزيج المثالي بين الرفاهية والطبيعة في لاسيرينا. شاليهك الخاص بانتظارك.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <a
              href="#chalets"
              className="rounded-full px-7 py-3 text-sm font-semibold transition hover:opacity-90"
              style={{ backgroundColor: "#E5DACE", color: "#0a192f" }}
            >
              احجز إقامتك
            </a>
            <a
              href="https://wa.me/201066380092"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full border px-7 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
              style={{ borderColor: "rgba(255,255,255,0.3)" }}
            >
              تواصل معنا
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/10">
        <div className="mx-auto max-w-[1440px] px-5 py-10 sm:px-10 md:px-20">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <div>
              <div className="text-lg font-bold text-white">La Sirena</div>
              <p className="mt-1 text-xs text-white/60">
                © 2026 لاسيرينا العين السخنة — رفاهية ساحلية.
              </p>
            </div>
            <p className="text-sm text-white/60">📍 العين السخنة، مصر</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
