import { createFileRoute, Link, notFound, Outlet, useRouterState } from "@tanstack/react-router";
import bg from "@/assets/lasirena-bg.jpg";
import { getChalet, type Chalet } from "@/lib/chalets";
import { Button } from "@/components/ui/button";
import { Phone, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/chalet/$id")({
  head: ({ params }) => {
    const c = getChalet(params.id);
    const title = c ? `${c.title} - ${c.subtitle} | لاسيرينا` : "شاليه | لاسيرينا";
    return {
      meta: [
        { title },
        { name: "description", content: c?.desc ?? "تفاصيل الشاليه" },
      ],
    };
  },
  loader: ({ params }) => {
    const chalet = getChalet(params.id);
    if (!chalet) throw notFound();
    return { chalet };
  },
  notFoundComponent: () => (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-background p-6 text-center">
      <div>
        <h1 className="text-2xl font-bold">الشاليه غير موجود</h1>
        <Link to="/" className="mt-4 inline-block text-primary underline">العودة للصفحة الرئيسية</Link>
      </div>
    </div>
  ),
  errorComponent: ({ reset }) => (
    <div dir="rtl" className="flex min-h-screen items-center justify-center p-6">
      <Button onClick={() => reset()}>حاول مرة أخرى</Button>
    </div>
  ),
  component: ChaletPage,
});

function ChaletPage() {
  const { chalet } = Route.useLoaderData() as { chalet: Chalet };
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  if (pathname.endsWith("/book")) {
    return <Outlet />;
  }

  const images = chalet.images && chalet.images.length > 0 ? chalet.images : [bg, bg, bg, bg];

  return (
    <div
      dir="rtl"
      lang="ar"
      className="min-h-screen w-full"
      style={{
        fontFamily: '"Noto Sans Arabic", "Be Vietnam Pro", sans-serif',
        backgroundColor: "#111415",
        color: "#e1e3e4",
      }}
    >
      <header className="sticky top-0 z-20 border-b border-white/10 backdrop-blur" style={{ backgroundColor: "rgba(6,18,36,0.7)" }}>
        <div className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-4 sm:px-10 md:px-20">
          <Link to="/" className="text-sm text-white/70 transition hover:text-white">← العودة</Link>
          <div className="text-right">
            <p className="text-[11px] font-bold uppercase tracking-[0.25em]" style={{ color: "#E5DACE" }}>{chalet.subtitle}</p>
            <h1 className="text-lg font-semibold text-white">{chalet.title}</h1>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-[1440px] px-5 py-14 sm:px-10 md:px-20">
        <p className="mb-6 max-w-3xl text-base leading-relaxed text-white/75 sm:text-lg">{chalet.desc}</p>
        {chalet.details && chalet.details.length > 0 && (
          <ul className="mb-10 grid max-w-3xl grid-cols-1 gap-2 sm:grid-cols-2">
            {chalet.details.map((d) => (
              <li
                key={d}
                className="flex items-center gap-3 rounded-lg border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/85"
              >
                <span aria-hidden style={{ color: "#E5DACE" }}>◆</span>
                {d}
              </li>
            ))}
          </ul>
        )}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {images.map((src, i) => (
            <div key={i} className="overflow-hidden rounded-2xl border border-white/10 bg-white/5">
              <img src={src} alt={`${chalet.title} - صورة ${i + 1}`} className="h-64 w-full object-cover sm:h-80" />
            </div>
          ))}
        </div>

        <div
          className="mt-12 rounded-2xl px-6 py-10 text-center sm:px-12"
          style={{
            background: "linear-gradient(135deg, rgba(10,25,47,0.9), rgba(6,18,36,0.95))",
            border: "1px solid rgba(229,218,206,0.2)",
          }}
        >
          <p className="text-[11px] font-bold uppercase tracking-[0.3em]" style={{ color: "#E5DACE" }}>PRICING</p>
          <h2 className="mt-3 text-2xl font-bold text-white sm:text-3xl">تواصل معنا لمعرفة السعر</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-white/70 sm:text-base">
            السعر يختلف حسب المدة والموسم. ابعتلنا واتساب أو اتصل بنا وهنرد عليك فورًا.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <a
              href="https://wa.me/201066380092"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition hover:opacity-90"
              style={{ backgroundColor: "#E5DACE", color: "#0a192f" }}
            >
              <MessageCircle className="h-4 w-4" />
              واتساب
            </a>
            <a
              href="tel:01066380092"
              className="inline-flex items-center gap-2 rounded-full border px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
              style={{ borderColor: "rgba(229,218,206,0.5)" }}
            >
              <Phone className="h-4 w-4" />
              اتصل بنا
            </a>
          </div>
        </div>

        <div className="mt-10 flex justify-center">
          <Link
            to="/chalet/$id/book"
            params={{ id: chalet.id }}
            className="inline-flex items-center gap-2 rounded-full px-8 py-3 text-base font-semibold transition hover:opacity-90"
            style={{ backgroundColor: "#E5DACE", color: "#0a192f" }}
          >
            عايز تعرف تفاصيل اكتر؟
            <span aria-hidden>←</span>
          </Link>
        </div>
      </section>
    </div>
  );
}