export type Chalet = {
  id: string;
  title: string;
  subtitle: string;
  desc: string;
  pricePerDay: number;
  bookedDates: string[]; // ISO yyyy-mm-dd
  images?: string[];
  details?: string[];
};

import rc1 from "@/assets/red-carpet/1.jpeg";
import rc2 from "@/assets/red-carpet/2.jpeg";
import rc3 from "@/assets/red-carpet/3.jpeg";
import rc4 from "@/assets/red-carpet/4.jpeg";
import rc5 from "@/assets/red-carpet/5.jpeg";
import rc6 from "@/assets/red-carpet/6.jpeg";
import rc7 from "@/assets/red-carpet/7.jpeg";
import rc8 from "@/assets/red-carpet/8.jpeg";
import rc9 from "@/assets/red-carpet/9.jpeg";
import b14_1 from "@/assets/b14/1.jpeg";
import b14_2 from "@/assets/b14/2.jpeg";
import b14_3 from "@/assets/b14/3.jpeg";
import b14_4 from "@/assets/b14/4.jpeg";
import b14_5 from "@/assets/b14/5.jpeg";
import b14_6 from "@/assets/b14/6.jpeg";
import b14_7 from "@/assets/b14/7.jpeg";
import b14_8 from "@/assets/b14/8.jpeg";
import s51_1 from "@/assets/s51/1.jpeg";
import s51_2 from "@/assets/s51/2.jpeg";
import s51_3 from "@/assets/s51/3.jpeg";
import s51_4 from "@/assets/s51/4.jpeg";
import s51_5 from "@/assets/s51/5.jpeg";
import s51_6 from "@/assets/s51/6.jpeg";
import s51_7 from "@/assets/s51/7.jpeg";

export const chalets: Chalet[] = [
  {
    id: 'red-carpet',
    title: 'شاليه K26',
    subtitle: 'Red Carpet',
    desc: 'شاليه K26 في المرحلة الرابعة ريد كاربت، غرفتين، دور تاني علوي، مكيف بالكامل.',
    pricePerDay: 1200,
    bookedDates: bookedRange(2026, 5, 15, 17),
    images: [rc1, rc2, rc3, rc4, rc5, rc6, rc7, rc8, rc9],
    details: [
      'رقم الشاليه: K26',
      'المرحلة الرابعة — ريد كاربت',
      'غرفتين',
      'دور تاني علوي',
      'مكيف بالكامل',
    ],
  },
  {
    id: 'b14',
    title: 'شاليه غرفتين',
    subtitle: 'Red Carpet',
    desc: 'شاليه B14 في المرحلة الخامسة ريد كاربت، غرفتين، دور أول علوي، مكيف بالكامل.',
    pricePerDay: 1800,
    bookedDates: bookedRange(2026, 5, 10, 12),
    images: [b14_1, b14_2, b14_3, b14_4, b14_5, b14_6, b14_7, b14_8],
    details: [
      'رقم الشاليه: B14',
      'المرحلة الخامسة — ريد كاربت',
      'غرفتين',
      'دور أول علوي',
      'مكيف بالكامل',
    ],
  },
  {
    id: 'lagoon-view',
    title: 'غرفة ورسبشن',
    subtitle: 'Pool View',
    desc: 'دور ارضي بجاردن',
    pricePerDay: 1500,
    bookedDates: bookedRange(2026, 5, 20, 22),
    images: [s51_1, s51_2, s51_3, s51_4, s51_5, s51_6, s51_7],
    details: [
      'رقم الشاليه: S51',
      'المرحلة الرابعة',
      'غرفة ورسبشن',
      'دور أرضي',
      'فيو على البول',
    ],
  },
];

function bookedRange(year: number, month: number, from: number, to: number): string[] {
  const out: string[] = [];
  for (let d = from; d <= to; d++) {
    const mm = String(month).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    out.push(`${year}-${mm}-${dd}`);
  }
  return out;
}

export function getChalet(id: string) {
  return chalets.find((c) => c.id === id);
}