import { chalets } from "./chalets";

const STORAGE_KEY = "lasirena.bookings.v1";

type BookingsMap = Record<string, string[]>; // chaletId -> ISO date strings

function readStore(): BookingsMap {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return seedFromStatic();
    return JSON.parse(raw) as BookingsMap;
  } catch {
    return {};
  }
}

function writeStore(map: BookingsMap) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  window.dispatchEvent(new CustomEvent("lasirena:bookings-updated"));
}

function seedFromStatic(): BookingsMap {
  const map: BookingsMap = {};
  for (const c of chalets) map[c.id] = [...c.bookedDates];
  if (typeof window !== "undefined") {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  }
  return map;
}

export function toIso(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function isoToDate(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function getBookedDates(chaletId: string): string[] {
  const store = readStore();
  return store[chaletId] ?? [];
}

export function setBookedDates(chaletId: string, dates: string[]) {
  const store = readStore();
  store[chaletId] = Array.from(new Set(dates)).sort();
  writeStore(store);
}

export function toggleBookedDate(chaletId: string, iso: string) {
  const current = getBookedDates(chaletId);
  const next = current.includes(iso)
    ? current.filter((d) => d !== iso)
    : [...current, iso];
  setBookedDates(chaletId, next);
}

export function subscribeBookings(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const handler = () => cb();
  window.addEventListener("lasirena:bookings-updated", handler);
  window.addEventListener("storage", handler);
  return () => {
    window.removeEventListener("lasirena:bookings-updated", handler);
    window.removeEventListener("storage", handler);
  };
}